import { useState } from "react";
import { X, CreditCard, Upload, Check } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { checkoutSchema, type CheckoutData } from "@shared/schema";
import { useStore } from "@/lib/store";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function CheckoutModal({ isOpen, onClose }: CheckoutModalProps) {
  const [paymentProof, setPaymentProof] = useState<File | null>(null);
  const { cart, clearCart, getCartTotal } = useStore();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<CheckoutData>({
    resolver: zodResolver(checkoutSchema),
    defaultValues: {
      customerName: "",
      customerPhone: "",
      customerAddress: "",
      items: JSON.stringify(cart),
      total: getCartTotal(),
    },
  });

  // Fetch QR code URL
  const { data: qrCodeSetting } = useQuery<{id: string, key: string, value: string}>({
    queryKey: ['/api/settings/qr_code_url'],
    enabled: isOpen,
  });

  // Fetch UPI ID
  const { data: upiIdSetting } = useQuery<{id: string, key: string, value: string}>({
    queryKey: ['/api/settings/upi_id'],
    enabled: isOpen,
  });

  const submitOrderMutation = useMutation({
    mutationFn: async (data: CheckoutData & { paymentProof?: File }) => {
      const formData = new FormData();
      formData.append('customerName', data.customerName);
      formData.append('customerPhone', data.customerPhone);
      formData.append('customerAddress', data.customerAddress);
      formData.append('items', data.items);
      formData.append('total', data.total.toString());
      
      if (data.paymentProof) {
        formData.append('paymentProof', data.paymentProof);
      }

      const response = await fetch('/api/orders', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to submit order');
      }

      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Order submitted successfully!",
        description: "Your order has been submitted and is pending verification.",
      });
      clearCart();
      onClose();
      form.reset();
      setPaymentProof(null);
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to submit order. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: CheckoutData) => {
    if (!paymentProof) {
      toast({
        title: "Payment proof required",
        description: "Please upload a screenshot of your payment.",
        variant: "destructive",
      });
      return;
    }

    submitOrderMutation.mutate({ ...data, paymentProof });
  };

  const formatPrice = (price: number) => {
    return `₹${(price / 100).toLocaleString('en-IN')}`;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-xl max-w-sm w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-xl font-bold text-gray-900">Checkout</h3>
            <button 
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600"
            >
              <X size={24} />
            </button>
          </div>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Customer Details */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Customer Details</h4>
                <div className="space-y-3">
                  <FormField
                    control={form.control}
                    name="customerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input placeholder="Full Name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="customerPhone"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input placeholder="Phone Number" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="customerAddress"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Textarea 
                            placeholder="Delivery Address" 
                            rows={3}
                            className="resize-none"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Payment QR Code */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Payment</h4>
                <div className="bg-gray-50 rounded-xl p-4 text-center">
                  <p className="text-sm text-gray-600 mb-4">
                    Scan QR code to pay {formatPrice(getCartTotal())}
                  </p>
                  {qrCodeSetting && (
                    <img 
                      src={qrCodeSetting.value} 
                      alt="Payment QR Code"
                      className="w-48 h-48 mx-auto rounded-lg border border-gray-200 mb-4"
                    />
                  )}
                  {upiIdSetting && (
                    <p className="text-xs text-gray-500">UPI ID: {upiIdSetting.value}</p>
                  )}
                </div>
              </div>

              {/* Payment Proof Upload */}
              <div>
                <h4 className="font-semibold text-gray-900 mb-3">Upload Payment Proof</h4>
                <div className="border-2 border-dashed border-gray-200 rounded-lg p-6 text-center">
                  {paymentProof ? (
                    <div className="space-y-2">
                      <Check className="mx-auto text-green-500" size={32} />
                      <p className="text-sm text-gray-600">{paymentProof.name}</p>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => setPaymentProof(null)}
                      >
                        Remove
                      </Button>
                    </div>
                  ) : (
                    <>
                      <Upload className="mx-auto text-gray-400 mb-2" size={32} />
                      <p className="text-sm text-gray-600 mb-2">Upload screenshot of payment</p>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) setPaymentProof(file);
                        }}
                        className="hidden"
                        id="paymentProof"
                      />
                      <label 
                        htmlFor="paymentProof"
                        className="inline-block bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium cursor-pointer hover:bg-indigo-700 transition-colors"
                      >
                        Choose File
                      </label>
                    </>
                  )}
                </div>
              </div>

              {/* Submit Order */}
              <Button
                type="submit"
                className="w-full bg-accent text-white hover:bg-emerald-600"
                disabled={submitOrderMutation.isPending}
              >
                <CreditCard className="mr-2" size={16} />
                {submitOrderMutation.isPending ? 'Submitting...' : 'Submit Order'}
              </Button>
            </form>
          </Form>
        </div>
      </div>
    </div>
  );
}
