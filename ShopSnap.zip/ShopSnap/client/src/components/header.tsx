import { ShoppingCart, Settings, Gem } from "lucide-react";
import { useStore } from "@/lib/store";

export function Header() {
  const { setCurrentPage, getCartItemCount } = useStore();
  const cartItemCount = getCartItemCount();

  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
            <Gem className="text-white text-sm" size={16} />
          </div>
          <h1 className="text-xl font-bold text-gray-900">Aurea Fashion</h1>
        </div>
        <div className="flex items-center space-x-3">
          <button 
            className="relative p-2"
            onClick={() => setCurrentPage('cart')}
          >
            <ShoppingCart className="text-gray-700" size={20} />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-primary text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {cartItemCount}
              </span>
            )}
          </button>
          <button 
            className="p-2"
            onClick={() => setCurrentPage('admin')}
          >
            <Settings className="text-gray-700" size={20} />
          </button>
        </div>
      </div>
    </header>
  );
}
