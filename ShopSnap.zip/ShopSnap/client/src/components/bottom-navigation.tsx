import { Home, ShoppingCart, Settings } from "lucide-react";
import { useStore } from "@/lib/store";

export function BottomNavigation() {
  const { currentPage, setCurrentPage, getCartItemCount } = useStore();
  const cartItemCount = getCartItemCount();

  const navItems = [
    { id: 'products' as const, label: 'Products', icon: Home },
    { id: 'cart' as const, label: 'Cart', icon: ShoppingCart },
    { id: 'admin' as const, label: 'Admin', icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 max-w-md w-full bg-white border-t border-gray-200 px-4 py-3">
      <div className="flex items-center justify-around">
        {navItems.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setCurrentPage(id)}
            className={`flex flex-col items-center space-y-1 ${
              currentPage === id ? 'text-primary' : 'text-gray-400'
            }`}
          >
            <div className="relative">
              <Icon size={20} />
              {id === 'cart' && cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-primary text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </div>
            <span className="text-xs font-medium">{label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
}
