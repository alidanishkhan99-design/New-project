import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Header } from "@/components/header";
import { BottomNavigation } from "@/components/bottom-navigation";
import { useStore } from "@/lib/store";
import ProductsPage from "@/pages/products";
import CartPage from "@/pages/cart";
import AdminPage from "@/pages/admin";

function AppContent() {
  const { currentPage } = useStore();

  return (
    <div className="max-w-md mx-auto bg-white min-h-screen relative">
      <Header />
      
      {currentPage === 'products' && <ProductsPage />}
      {currentPage === 'cart' && <CartPage />}
      {currentPage === 'admin' && <AdminPage />}
      
      <BottomNavigation />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <AppContent />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
