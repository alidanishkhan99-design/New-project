import { useState } from "react";
import { CreditCard } from "lucide-react";
import { useStore } from "@/lib/store";
import { CartItem } from "@/components/cart-item";
import { CheckoutModal } from "@/components/checkout-modal";
import { Button } from "@/components/ui/button";

export default function CartPage() {
  const [showCheckout, setShowCheckout] = useState(false);
  const { cart, clearCart, getCartTotal } = useStore();

  const formatPrice = (price: number) => {
    return `₹${(price / 100).toLocaleString('en-IN')}`;
  };

  const subtotal = getCartTotal();
  const deliveryFee = 0; // Free delivery
  const total = subtotal + deliveryFee;

  if (cart.length === 0) {
    return (
      <div className="pb-20 p-4">
        <div className="text-center py-12">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Your cart is empty</h2>
          <p className="text-gray-500">Add some products to get started!</p>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-20">
      <div className="p-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Shopping Cart</h2>
          <Button variant="outline" onClick={clearCart}>
            Clear All
          </Button>
        </div>

        {/* Cart Items */}
        <div className="space-y-4 mb-6">
          {cart.map(item => (
            <CartItem key={item.id} item={item} />
          ))}
        </div>

        {/* Order Summary */}
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 mb-6">
          <h3 className="font-semibold text-gray-900 mb-3">Order Summary</h3>
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-gray-600">Subtotal</span>
              <span>{formatPrice(subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Delivery</span>
              <span className="text-accent">Free</span>
            </div>
            <div className="border-t border-gray-100 pt-2 mt-2">
              <div className="flex justify-between font-bold text-lg">
                <span>Total</span>
                <span className="text-primary">{formatPrice(total)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Checkout Button */}
        <Button
          onClick={() => setShowCheckout(true)}
          className="w-full bg-primary text-white hover:bg-indigo-700 py-4 text-lg font-semibold"
        >
          <CreditCard className="mr-2" size={20} />
          Proceed to Checkout
        </Button>
      </div>

      <CheckoutModal 
        isOpen={showCheckout}
        onClose={() => setShowCheckout(false)}
      />
    </div>
  );
}
