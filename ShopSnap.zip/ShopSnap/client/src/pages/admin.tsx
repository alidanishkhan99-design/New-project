import { useState } from "react";
import { Eye, Check, Save, Upload, X, Plus, Edit, Trash2 } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { insertProductSchema, type Order, type Product, type InsertProduct } from "@shared/schema";

export default function AdminPage() {
  const [selectedPaymentProof, setSelectedPaymentProof] = useState<string | null>(null);
  const [newQrCode, setNewQrCode] = useState<File | null>(null);
  const [upiId, setUpiId] = useState("");
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showProductForm, setShowProductForm] = useState(false);
  const [productImage, setProductImage] = useState<File | null>(null);
  const { setCurrentPage } = useStore();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch orders
  const { data: orders = [], isLoading: ordersLoading } = useQuery<Order[]>({
    queryKey: ['/api/orders'],
  });

  // Fetch products
  const { data: products = [], isLoading: productsLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });

  // Fetch settings
  const { data: upiIdSetting } = useQuery<{id: string, key: string, value: string}>({
    queryKey: ['/api/settings/upi_id'],
  });

  const { data: qrCodeSetting } = useQuery<{id: string, key: string, value: string}>({
    queryKey: ['/api/settings/qr_code_url'],
  });

  // Update UPI ID when data is fetched
  if (upiIdSetting && upiId !== upiIdSetting.value) {
    setUpiId(upiIdSetting.value);
  }

  // Product form
  const productForm = useForm<InsertProduct & { priceInRupees: number }>({
    resolver: zodResolver(insertProductSchema.extend({
      priceInRupees: insertProductSchema.shape.price.transform(val => val / 100)
    })),
    defaultValues: {
      name: "",
      priceInRupees: 0,
      category: "all",
      inStock: true,
    },
  });

  // Verify order mutation
  const verifyOrderMutation = useMutation({
    mutationFn: async (orderId: string) => {
      const response = await fetch(`/api/orders/${orderId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'verified' }),
      });
      if (!response.ok) throw new Error('Failed to verify order');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Order verified",
        description: "Order has been marked as verified.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
    },
  });

  // Update settings mutation
  const updateSettingsMutation = useMutation({
    mutationFn: async (data: { key: string; value?: string; file?: File }) => {
      const formData = new FormData();
      formData.append('key', data.key);
      if (data.value) formData.append('value', data.value);
      if (data.file) formData.append('qrCode', data.file);

      const response = await fetch('/api/settings', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Failed to update settings');
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "Settings have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/settings/upi_id'] });
      queryClient.invalidateQueries({ queryKey: ['/api/settings/qr_code_url'] });
      setNewQrCode(null);
    },
  });

  // Product mutations
  const createProductMutation = useMutation({
    mutationFn: async (data: InsertProduct & { priceInRupees: number; productImage?: File }) => {
      const formData = new FormData();
      formData.append('name', data.name);
      formData.append('price', data.priceInRupees.toString());
      formData.append('category', data.category || "all");
      formData.append('inStock', (data.inStock ?? true).toString());
      if (data.productImage) formData.append('productImage', data.productImage);

      const response = await fetch('/api/products', {
        method: 'POST',
        body: formData,
      });
      if (!response.ok) throw new Error('Failed to create product');
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Product created", description: "Product has been added successfully." });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setShowProductForm(false);
      setProductImage(null);
      productForm.reset();
    },
  });

  const updateProductMutation = useMutation({
    mutationFn: async (data: { id: string; updates: Partial<InsertProduct & { priceInRupees: number }>; productImage?: File }) => {
      const formData = new FormData();
      if (data.updates.name) formData.append('name', data.updates.name);
      if (data.updates.priceInRupees) formData.append('price', data.updates.priceInRupees.toString());
      if (data.updates.category) formData.append('category', data.updates.category);
      if (data.updates.inStock !== undefined) formData.append('inStock', data.updates.inStock.toString());
      if (data.productImage) formData.append('productImage', data.productImage);

      const response = await fetch(`/api/products/${data.id}`, {
        method: 'PATCH',
        body: formData,
      });
      if (!response.ok) throw new Error('Failed to update product');
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Product updated", description: "Product has been updated successfully." });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setEditingProduct(null);
      setShowProductForm(false);
      setProductImage(null);
      productForm.reset();
    },
  });

  const deleteProductMutation = useMutation({
    mutationFn: async (productId: string) => {
      const response = await fetch(`/api/products/${productId}`, { method: 'DELETE' });
      if (!response.ok) throw new Error('Failed to delete product');
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Product deleted", description: "Product has been removed successfully." });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
    },
  });

  const formatPrice = (price: number) => {
    return `₹${(price / 100).toLocaleString('en-IN')}`;
  };

  const formatDate = (date: Date | string) => {
    return new Date(date).toLocaleString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const handleUpdateSettings = () => {
    if (newQrCode) {
      updateSettingsMutation.mutate({
        key: 'qr_code_url',
        file: newQrCode,
      });
    }

    if (upiId !== upiIdSetting?.value) {
      updateSettingsMutation.mutate({
        key: 'upi_id',
        value: upiId,
      });
    }
  };

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    productForm.reset({
      name: product.name,
      priceInRupees: product.price / 100,
      category: product.category,
      inStock: product.inStock,
    });
    setShowProductForm(true);
  };

  const handleProductSubmit = (data: InsertProduct & { priceInRupees: number }) => {
    if (editingProduct) {
      updateProductMutation.mutate({
        id: editingProduct.id,
        updates: data,
        productImage: productImage || undefined,
      });
    } else {
      createProductMutation.mutate({
        ...data,
        productImage: productImage || undefined,
      });
    }
  };

  const handleCancelProductForm = () => {
    setShowProductForm(false);
    setEditingProduct(null);
    setProductImage(null);
    productForm.reset();
  };

  return (
    <div className="pb-20">
      <div className="p-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">Admin Panel</h2>
          <Button
            variant="outline"
            onClick={() => setCurrentPage('products')}
          >
            <X size={16} />
          </Button>
        </div>

        <Tabs defaultValue="orders" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="orders">Orders</TabsTrigger>
            <TabsTrigger value="products">Products</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="orders" className="space-y-4">
            {ordersLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="bg-gray-200 rounded-xl h-32 animate-pulse" />
                ))}
              </div>
            ) : orders.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500">No orders found</p>
              </div>
            ) : (
              orders.map(order => {
                const items = JSON.parse(order.items);
                return (
                  <div key={order.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="font-semibold text-gray-900">Order #{order.id.slice(-6).toUpperCase()}</h3>
                        <p className="text-sm text-gray-600">{order.customerName} - {order.customerPhone}</p>
                        <p className="text-sm text-gray-600">{formatDate(order.createdAt)}</p>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(order.status)}`}>
                        {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                      </span>
                    </div>
                    <div className="border-t border-gray-100 pt-3">
                      <p className="text-sm text-gray-600 mb-2">
                        Items: {items.map((item: any) => `${item.name} (${item.quantity})`).join(', ')}
                      </p>
                      <p className="text-sm text-gray-600 mb-2">Address: {order.customerAddress}</p>
                      <p className="font-semibold text-primary mb-3">Total: {formatPrice(order.total)}</p>
                      <div className="flex items-center space-x-3">
                        {order.paymentProofUrl && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => setSelectedPaymentProof(order.paymentProofUrl)}
                          >
                            <Eye className="mr-2" size={14} />
                            View Proof
                          </Button>
                        )}
                        <Button
                          size="sm"
                          onClick={() => verifyOrderMutation.mutate(order.id)}
                          disabled={order.status === 'verified' || verifyOrderMutation.isPending}
                          className={order.status === 'verified' ? 'bg-gray-300 cursor-not-allowed' : 'bg-accent hover:bg-emerald-600'}
                        >
                          <Check className="mr-2" size={14} />
                          {order.status === 'verified' ? 'Verified' : 'Verify'}
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </TabsContent>

          <TabsContent value="products" className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold">Product Management</h3>
              <Button onClick={() => setShowProductForm(true)} disabled={showProductForm}>
                <Plus className="mr-2" size={16} />
                Add Product
              </Button>
            </div>

            {/* Product Form */}
            {showProductForm && (
              <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                <h4 className="font-semibold text-gray-900 mb-4">
                  {editingProduct ? 'Edit Product' : 'Add New Product'}
                </h4>
                <Form {...productForm}>
                  <form onSubmit={productForm.handleSubmit(handleProductSubmit)} className="space-y-4">
                    <FormField
                      control={productForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter product name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={productForm.control}
                      name="priceInRupees"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Price (₹)</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="Enter price in rupees" 
                              {...field}
                              onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={productForm.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="all">All</SelectItem>
                              <SelectItem value="dresses">Dresses</SelectItem>
                              <SelectItem value="tops">Tops</SelectItem>
                              <SelectItem value="accessories">Accessories</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={productForm.control}
                      name="inStock"
                      render={({ field }) => (
                        <FormItem className="flex items-center space-x-3">
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <FormLabel>In Stock</FormLabel>
                        </FormItem>
                      )}
                    />

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Product Image</label>
                      <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 text-center">
                        {productImage ? (
                          <div className="space-y-2">
                            <Check className="mx-auto text-green-500" size={24} />
                            <p className="text-sm text-gray-600">{productImage.name}</p>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => setProductImage(null)}
                            >
                              Remove
                            </Button>
                          </div>
                        ) : (
                          <>
                            <Upload className="mx-auto text-gray-400 mb-2" size={24} />
                            <p className="text-sm text-gray-600 mb-2">Upload product image</p>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) setProductImage(file);
                              }}
                              className="hidden"
                              id="productImageUpload"
                            />
                            <label 
                              htmlFor="productImageUpload"
                              className="inline-block bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium cursor-pointer hover:bg-indigo-700 transition-colors"
                            >
                              Choose File
                            </label>
                          </>
                        )}
                      </div>
                    </div>

                    <div className="flex space-x-3">
                      <Button
                        type="submit"
                        disabled={createProductMutation.isPending || updateProductMutation.isPending}
                        className="flex-1"
                      >
                        <Save className="mr-2" size={16} />
                        {editingProduct ? 'Update Product' : 'Create Product'}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={handleCancelProductForm}
                        className="flex-1"
                      >
                        Cancel
                      </Button>
                    </div>
                  </form>
                </Form>
              </div>
            )}

            {/* Products List */}
            {productsLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="bg-gray-200 rounded-xl h-24 animate-pulse" />
                ))}
              </div>
            ) : products.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500">No products found</p>
              </div>
            ) : (
              <div className="space-y-4">
                {products.map(product => (
                  <div key={product.id} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
                    <div className="flex items-center space-x-4">
                      <img 
                        src={product.imageUrl} 
                        alt={product.name}
                        className="w-16 h-16 rounded-lg object-cover"
                      />
                      <div className="flex-1">
                        <h4 className="font-semibold text-gray-900">{product.name}</h4>
                        <p className="text-primary font-bold">{formatPrice(product.price)}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-xs bg-gray-100 px-2 py-1 rounded-full">{product.category}</span>
                          <span className={`text-xs px-2 py-1 rounded-full ${product.inStock ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                            {product.inStock ? 'In Stock' : 'Out of Stock'}
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditProduct(product)}
                          disabled={showProductForm}
                        >
                          <Edit className="mr-1" size={14} />
                          Edit
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => deleteProductMutation.mutate(product.id)}
                          disabled={deleteProductMutation.isPending}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="mr-1" size={14} />
                          Delete
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-900 mb-4">Payment Settings</h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">UPI ID</label>
                  <Input
                    value={upiId}
                    onChange={(e) => setUpiId(e.target.value)}
                    placeholder="Enter UPI ID"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">QR Code</label>
                  {qrCodeSetting && (
                    <div className="mb-3">
                      <img 
                        src={qrCodeSetting.value} 
                        alt="Current QR Code"
                        className="w-32 h-32 rounded-lg border border-gray-200"
                      />
                      <p className="text-xs text-gray-500 mt-1">Current QR Code</p>
                    </div>
                  )}
                  
                  <div className="border-2 border-dashed border-gray-200 rounded-lg p-4 text-center">
                    {newQrCode ? (
                      <div className="space-y-2">
                        <Check className="mx-auto text-green-500" size={24} />
                        <p className="text-sm text-gray-600">{newQrCode.name}</p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setNewQrCode(null)}
                        >
                          Remove
                        </Button>
                      </div>
                    ) : (
                      <>
                        <Upload className="mx-auto text-gray-400 mb-2" size={24} />
                        <p className="text-sm text-gray-600 mb-2">Upload new QR code</p>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) => {
                            const file = e.target.files?.[0];
                            if (file) setNewQrCode(file);
                          }}
                          className="hidden"
                          id="qrCodeUpload"
                        />
                        <label 
                          htmlFor="qrCodeUpload"
                          className="inline-block bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium cursor-pointer hover:bg-indigo-700 transition-colors"
                        >
                          Choose File
                        </label>
                      </>
                    )}
                  </div>
                </div>
                
                <Button
                  onClick={handleUpdateSettings}
                  disabled={updateSettingsMutation.isPending}
                  className="w-full"
                >
                  <Save className="mr-2" size={16} />
                  {updateSettingsMutation.isPending ? 'Updating...' : 'Update Settings'}
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Payment Proof Modal */}
      {selectedPaymentProof && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-sm w-full">
            <div className="p-4">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold">Payment Proof</h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedPaymentProof(null)}
                >
                  <X size={16} />
                </Button>
              </div>
              <img 
                src={selectedPaymentProof}
                alt="Payment Proof"
                className="w-full rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
