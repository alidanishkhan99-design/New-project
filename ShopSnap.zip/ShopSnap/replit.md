# Overview

Aurea Fashion is a mobile-first e-commerce application for a fashion boutique. The application provides a modern shopping experience with features including product browsing, shopping cart functionality, order management, payment processing via UPI, and comprehensive admin product management. The system is designed as a full-stack web application with a React frontend and Express backend, utilizing PostgreSQL for data persistence.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: Zustand for client-side state with persistence
- **Data Fetching**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **UI Components**: Radix UI primitives with custom styling
- **Build Tool**: Vite with hot module replacement

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful APIs with JSON responses
- **File Handling**: Multer for image uploads with 5MB size limits
- **Development**: Hot reload with tsx for development server
- **Error Handling**: Centralized error middleware with proper HTTP status codes

## Data Storage Solutions
- **Database**: PostgreSQL with Neon serverless hosting
- **ORM**: Drizzle ORM for type-safe database operations
- **Schema Management**: Drizzle Kit for migrations
- **Validation**: Zod schemas for runtime type validation
- **Storage Strategy**: In-memory fallback storage for development with interface abstraction

## Database Schema Design
- **Products**: Core product catalog with pricing in paise for precision
- **Orders**: Customer orders with JSON-serialized cart items
- **Settings**: Key-value configuration store for app settings
- **Relationships**: Simple flat structure optimized for boutique-scale operations

## Authentication and Authorization
- **Current State**: No authentication system implemented
- **Admin Access**: Open admin panel for order and product management
- **Security Model**: Relies on deployment-level access controls

## Payment Integration
- **Method**: UPI-based payments with QR code generation
- **Flow**: Customer uploads payment proof screenshots for manual verification
- **Verification**: Admin panel for order status management
- **Settings**: Configurable UPI ID and QR code through admin interface

## Mobile-First Design
- **Responsive**: Optimized for mobile devices with max-width constraints
- **Navigation**: Bottom navigation bar for primary user flows
- **Layout**: Card-based design with touch-friendly interactions
- **Typography**: Inter font family for modern, readable interface

## Development Workflow
- **Hot Reload**: Vite development server with Express API proxy
- **Type Safety**: Shared TypeScript types between frontend and backend
- **Build Process**: Separate builds for client (Vite) and server (esbuild)
- **Development Tools**: Replit integration with runtime error overlays

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting
- **Connection**: Environment-based connection string configuration

## UI Component Libraries
- **Radix UI**: Accessible component primitives for complex UI elements
- **shadcn/ui**: Pre-built component library built on Radix UI
- **Lucide React**: Icon library for consistent iconography

## State Management
- **Zustand**: Lightweight state management with persistence middleware
- **TanStack Query**: Server state management with caching and synchronization

## Development Tools
- **Tailwind CSS**: Utility-first CSS framework
- **PostCSS**: CSS processing with autoprefixer
- **TypeScript**: Static type checking across the entire stack
- **Vite**: Fast build tool with HMR for development

## File Processing
- **Multer**: Multipart form data handling for image uploads
- **File System**: Local file storage for uploaded payment proofs

## Date and Time
- **date-fns**: Date manipulation and formatting utilities

## Form Handling
- **React Hook Form**: Form state management with validation
- **Hookform Resolvers**: Integration between React Hook Form and Zod validation

## Carousel Components
- **Embla Carousel**: Touch-friendly carousel implementation for product displays