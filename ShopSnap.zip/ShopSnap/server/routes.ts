import type { Express, Request } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertOrderSchema, checkoutSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

// Extend Request type to include file property for multer
interface MulterRequest extends Request {
  file?: Express.Multer.File;
}

// Setup multer for file uploads
const uploadDir = path.join(process.cwd(), "uploads");
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const upload = multer({
  dest: uploadDir,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: (req: Request, file: Express.Multer.File, cb: multer.FileFilterCallback) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  },
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all products
  app.get("/api/products", async (req, res) => {
    try {
      const products = await storage.getProducts();
      res.json(products);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch products" });
    }
  });

  // Get single product
  app.get("/api/products/:id", async (req, res) => {
    try {
      const product = await storage.getProduct(req.params.id);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch product" });
    }
  });

  // Create product (admin)
  app.post("/api/products", upload.single('productImage'), async (req: MulterRequest, res) => {
    try {
      const { name, price, category = "all", inStock = true } = req.body;
      
      let imageUrl = "https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400";
      if (req.file) {
        // Generate unique filename and move file
        const filename = `product_${Date.now()}_${req.file.originalname}`;
        const finalPath = path.join(uploadDir, filename);
        fs.renameSync(req.file.path, finalPath);
        imageUrl = `/uploads/${filename}`;
      }

      const product = await storage.createProduct({
        name,
        price: parseInt(price) * 100, // Convert to paise
        imageUrl,
        category,
        inStock: inStock === 'true' || inStock === true,
      });

      res.json(product);
    } catch (error) {
      res.status(400).json({ message: "Invalid product data" });
    }
  });

  // Update product (admin)
  app.patch("/api/products/:id", upload.single('productImage'), async (req: MulterRequest, res) => {
    try {
      const { name, price, category, inStock } = req.body;
      const updateData: any = {};
      
      if (name) updateData.name = name;
      if (price) updateData.price = parseInt(price) * 100; // Convert to paise
      if (category) updateData.category = category;
      if (inStock !== undefined) updateData.inStock = inStock === 'true' || inStock === true;
      
      if (req.file) {
        // Generate unique filename and move file
        const filename = `product_${Date.now()}_${req.file.originalname}`;
        const finalPath = path.join(uploadDir, filename);
        fs.renameSync(req.file.path, finalPath);
        updateData.imageUrl = `/uploads/${filename}`;
      }

      const product = await storage.updateProduct(req.params.id, updateData);
      if (!product) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json(product);
    } catch (error) {
      res.status(500).json({ message: "Failed to update product" });
    }
  });

  // Delete product (admin)
  app.delete("/api/products/:id", async (req, res) => {
    try {
      const deleted = await storage.deleteProduct(req.params.id);
      if (!deleted) {
        return res.status(404).json({ message: "Product not found" });
      }
      res.json({ message: "Product deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete product" });
    }
  });

  // Create order with payment proof
  app.post("/api/orders", upload.single('paymentProof'), async (req: MulterRequest, res) => {
    try {
      const orderData = checkoutSchema.parse(req.body);
      
      let paymentProofUrl = null;
      if (req.file) {
        // Generate unique filename and move file
        const filename = `payment_${Date.now()}_${req.file.originalname}`;
        const finalPath = path.join(uploadDir, filename);
        fs.renameSync(req.file.path, finalPath);
        paymentProofUrl = `/uploads/${filename}`;
      }

      const order = await storage.createOrder({
        ...orderData,
        paymentProofUrl,
        status: "pending",
      });

      res.json(order);
    } catch (error) {
      res.status(400).json({ message: "Invalid order data" });
    }
  });

  // Get all orders (admin)
  app.get("/api/orders", async (req, res) => {
    try {
      const orders = await storage.getOrders();
      res.json(orders);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch orders" });
    }
  });

  // Update order status (admin)
  app.patch("/api/orders/:id", async (req, res) => {
    try {
      const { status } = req.body;
      const order = await storage.updateOrder(req.params.id, { status });
      if (!order) {
        return res.status(404).json({ message: "Order not found" });
      }
      res.json(order);
    } catch (error) {
      res.status(500).json({ message: "Failed to update order" });
    }
  });

  // Get settings
  app.get("/api/settings/:key", async (req, res) => {
    try {
      const setting = await storage.getSetting(req.params.key);
      if (!setting) {
        return res.status(404).json({ message: "Setting not found" });
      }
      res.json(setting);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch setting" });
    }
  });

  // Update settings (admin)
  app.post("/api/settings", upload.single('qrCode'), async (req: MulterRequest, res) => {
    try {
      const { key, value } = req.body;
      
      let finalValue = value;
      if (key === 'qr_code_url' && req.file) {
        // Handle QR code upload
        const filename = `qr_code_${Date.now()}_${req.file.originalname}`;
        const finalPath = path.join(uploadDir, filename);
        fs.renameSync(req.file.path, finalPath);
        finalValue = `/uploads/${filename}`;
      }

      const setting = await storage.setSetting(key, finalValue);
      res.json(setting);
    } catch (error) {
      res.status(500).json({ message: "Failed to update setting" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', express.static(uploadDir));

  const httpServer = createServer(app);
  return httpServer;
}
