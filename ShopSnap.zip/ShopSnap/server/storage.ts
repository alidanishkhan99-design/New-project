import { type Product, type InsertProduct, type Order, type InsertOrder, type Setting, type InsertSetting } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getProduct(id: string): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  
  // Orders
  getOrders(): Promise<Order[]>;
  getOrder(id: string): Promise<Order | undefined>;
  createOrder(order: InsertOrder): Promise<Order>;
  updateOrder(id: string, order: Partial<InsertOrder>): Promise<Order | undefined>;
  
  // Settings
  getSetting(key: string): Promise<Setting | undefined>;
  setSetting(key: string, value: string): Promise<Setting>;
}

export class MemStorage implements IStorage {
  private products: Map<string, Product>;
  private orders: Map<string, Order>;
  private settings: Map<string, Setting>;

  constructor() {
    this.products = new Map();
    this.orders = new Map();
    this.settings = new Map();
    
    // Initialize with sample products
    this.initializeProducts();
    this.initializeSettings();
  }

  private initializeProducts() {
    const sampleProducts: InsertProduct[] = [
      {
        name: "Elegant Summer Dress",
        price: 249900, // ₹2,499 in paise
        imageUrl: "https://images.unsplash.com/photo-1595777457583-95e059d581b8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        category: "dresses",
        inStock: true,
      },
      {
        name: "Casual Chic Top",
        price: 129900, // ₹1,299 in paise
        imageUrl: "https://images.unsplash.com/photo-1571945153237-4929e783af4a?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        category: "tops",
        inStock: true,
      },
      {
        name: "Designer Handbag",
        price: 399900, // ₹3,999 in paise
        imageUrl: "https://images.unsplash.com/photo-1584917865442-de89df76afd3?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        category: "accessories",
        inStock: true,
      },
      {
        name: "Trendy Jacket",
        price: 289900, // ₹2,899 in paise
        imageUrl: "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        category: "tops",
        inStock: true,
      },
      {
        name: "Pearl Necklace",
        price: 179900, // ₹1,799 in paise
        imageUrl: "https://images.unsplash.com/photo-1515562141207-7a88fb7ce338?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        category: "accessories",
        inStock: true,
      },
      {
        name: "Comfort Sneakers",
        price: 329900, // ₹3,299 in paise
        imageUrl: "https://images.unsplash.com/photo-1549298916-b41d501d3772?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=400",
        category: "accessories",
        inStock: true,
      },
    ];

    sampleProducts.forEach(product => {
      const id = randomUUID();
      const fullProduct: Product = { 
        ...product, 
        id,
        category: product.category || "all",
        inStock: product.inStock ?? true
      };
      this.products.set(id, fullProduct);
    });
  }

  private initializeSettings() {
    this.setSetting("upi_id", "aurea@paytm");
    this.setSetting("qr_code_url", "https://pixabay.com/get/gca180f8cb8e9f97692545be7632dec26517a83deb5e1eccebe0969405783596adf23ed90207d90a1a79c6526beecb5d9e875fc9fbb7efd3479a73b4c2edc76ca_1280.jpg");
  }

  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getProduct(id: string): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = { 
      ...insertProduct, 
      id,
      category: insertProduct.category || "all",
      inStock: insertProduct.inStock ?? true
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, updateData: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { ...product, ...updateData };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  async getOrders(): Promise<Order[]> {
    return Array.from(this.orders.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async getOrder(id: string): Promise<Order | undefined> {
    return this.orders.get(id);
  }

  async createOrder(insertOrder: InsertOrder): Promise<Order> {
    const id = randomUUID();
    const order: Order = {
      ...insertOrder,
      id,
      status: insertOrder.status || "pending",
      paymentProofUrl: insertOrder.paymentProofUrl || null,
      createdAt: new Date(),
    };
    this.orders.set(id, order);
    return order;
  }

  async updateOrder(id: string, updateData: Partial<InsertOrder>): Promise<Order | undefined> {
    const order = this.orders.get(id);
    if (!order) return undefined;
    
    const updatedOrder = { ...order, ...updateData };
    this.orders.set(id, updatedOrder);
    return updatedOrder;
  }

  async getSetting(key: string): Promise<Setting | undefined> {
    return this.settings.get(key);
  }

  async setSetting(key: string, value: string): Promise<Setting> {
    const existing = this.settings.get(key);
    const setting: Setting = {
      id: existing?.id || randomUUID(),
      key,
      value,
    };
    this.settings.set(key, setting);
    return setting;
  }
}

export const storage = new MemStorage();
